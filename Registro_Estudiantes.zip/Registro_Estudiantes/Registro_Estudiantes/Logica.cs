﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registro_Estudiantes
{
    class Logica
    {
        private string idUsuario;
        private string clave;

        public string IdUsuario
        {
            get
            {
                return idUsuario;
            }
            set
            {
                idUsuario = value;
            }
        }
        public string Clave
        {
            get
            {
                return clave;
            }
            set
            {
                clave = value;
            }
        }
        public static bool VerificaUsuario(string idUsuario, string clave)
        {
            bool conexionExitosa = false;
            int contadorRegistros = ConexionSQLServer.VerificaUsuarios(idUsuario, clave);

            if (contadorRegistros == 0)
            {
                conexionExitosa = false;
            }
            else
            {
                conexionExitosa = true;
            }

            return conexionExitosa;
        }
    }
}
