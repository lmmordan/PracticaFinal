﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registro_Estudiantes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Logica.VerificaUsuario(tbUsuario.Text, tbContraseña.Text))
            {
                frmMenu menu = new frmMenu();

                menu.Show();
                this.Hide();
            }
            else
            {
                tbUsuario.Text = "";
                tbContraseña.Text = "";
                tbUsuario.Focus();
                lblMesajeAutenticacion.Text = "Usuario o contraseña incorrectos.";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ConexionSQLServer sqlcon = new ConexionSQLServer();
            ConexionSQLServer.ConectaSQL();
        }
    }
}
