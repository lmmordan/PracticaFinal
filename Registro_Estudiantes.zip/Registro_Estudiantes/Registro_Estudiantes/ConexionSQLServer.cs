﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Registro_Estudiantes
{
    class ConexionSQLServer
    {
        string servidor = "DESKTOP-28S9PLH";
        string baseDeDatos = "RegistroEstudiantes";
        public static string cadenaConexion;
        public static string mensajeConexion;
        public ConexionSQLServer()
        {
            //mensajeConexion = "";
            cadenaConexion = "Data Source =" + servidor + ";" + "Initial catalog=" + baseDeDatos + ";" + "Integrated security = true";
        }

        public static void ConectaSQL()
        {
            SqlConnection con = new SqlConnection(cadenaConexion);
            try
            {
                con.Open();
                mensajeConexion = "Conectado.";
            }
            catch (Exception ex)
            {

                mensajeConexion = ex.ToString();
            }
        }
        public static SqlConnection DevuelveCon()
        {
            SqlConnection con = new SqlConnection(cadenaConexion);
            try
            {
                con.Open();
                mensajeConexion = "Conectado.";
            }
            catch (Exception ex)
            {

                mensajeConexion = ex.ToString();
            }
            return con;
        }
        public static SqlConnection ConectaSQL(string cadena)
        {
            cadena = cadenaConexion;
            SqlConnection con = new SqlConnection(cadena);
            if (con.State == ConnectionState.Closed || con.State == ConnectionState.Broken)
            {
                con.Open();
            }

            return con;
        }
        public static int VerificaUsuarios(string usuario, string clave)
        {
            int contador = 0;

            string query = "Select * from dbo.Usuario where NombreUsuario = '" + usuario + "' and Clave = '" + clave + "'";
            SqlCommand comando = new SqlCommand(query, ConectaSQL(cadenaConexion));
            SqlDataReader SQLdr = comando.ExecuteReader();

            while (SQLdr.Read())
            {
                contador++;
            }
            return contador;
        }
        public static void RegistrarEstudiante(string nombres, string apellidos, string direccion, int idCarrera)
        {
            string query = "Insert into dbo.Estudiantes (Nombres, Apellidos, Direccion, idCarrera) values('" + nombres + "', '" + apellidos + "','" + direccion + "'," + idCarrera + ")";
            SqlCommand c = new SqlCommand(query, ConectaSQL(cadenaConexion));
            c.ExecuteNonQuery();
        }
    }
}
