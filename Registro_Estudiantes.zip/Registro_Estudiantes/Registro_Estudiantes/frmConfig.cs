﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registro_Estudiantes
{
    public partial class frmConfig : Form
    {
        public object FormManager { get; private set; }

        public frmConfig()
        {
            InitializeComponent();
        }

        private void rbRojo_CheckedChanged(object sender, EventArgs e)
        {
           
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
           
        }

        private void frmConfig_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmMenu menu = new frmMenu();;
            menu.Show();
            this.Hide();
            
        }
    }
}
