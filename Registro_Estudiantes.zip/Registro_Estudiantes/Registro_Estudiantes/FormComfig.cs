﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Registro_Estudiantes
{
    public partial class FormComfig : Form
    {
        Color colorFondo = Properties.Settings.Default.FormsBackgroundColor;
    }
}
