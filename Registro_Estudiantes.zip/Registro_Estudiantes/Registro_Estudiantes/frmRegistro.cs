﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Registro_Estudiantes
{
    public partial class frmRegistro : Form
    {
        public frmRegistro()
        {
            InitializeComponent();
        }

        private void frmRegistro_Load(object sender, EventArgs e)
        {
            DateTime fechaActual = DateTime.Now;
            label6.Text = fechaActual.ToString();
            SqlConnection con = ConexionSQLServer.ConectaSQL(ConexionSQLServer.cadenaConexion);
            string query = "Select Carrera from dbo.Carreras";
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            //con.Open();
            DataSet ds = new DataSet();
            da.Fill(ds, "Carreras");
            cbCarrera.DisplayMember = "Carrera";
            cbCarrera.ValueMember = "IdCarrera";
            cbCarrera.DataSource = ds.Tables["Carreras"];
            
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            frmMenu menu = new frmMenu();
            menu.Show();
            this.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {

            DataRowView drv = (DataRowView)cbCarrera.SelectedItem;
            string Carrera = drv["NombreCarrera"].ToString();

            int idCarrera= 0;
            switch (Carrera.ToString())
            {
                case "Ingenieria en Sistemas": idCarrera = 1;
                    break;
                case "Contabilidad":idCarrera = 2;
                    break;
                default: idCarrera = 0;
                    break;
            }
            
            ConexionSQLServer.RegistrarEstudiante(tbNombres.Text, tbApellidos.Text, tbDireccion.Text, idCarrera);
            MessageBox.Show("Registro completado");
            tbNombres.Text = "";
            tbApellidos.Text = "";
            tbDireccion.Text = "";
        }
    }
}
