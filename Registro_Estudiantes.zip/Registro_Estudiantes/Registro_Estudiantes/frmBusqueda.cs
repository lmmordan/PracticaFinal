﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Registro_Estudiantes
{
    public partial class frmBusqueda : Form
    {
        public frmBusqueda()
        {
            InitializeComponent();
        }

        private void frmBusqueda_FormClosed(object sender, FormClosedEventArgs e)
        {
            frmMenu menu = new frmMenu();
            menu.Show();
            //this.Close();
        }

        private void frmBusqueda_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'registroEstudiantesDataSet.Estudiantes_busqueda' table. You can move, or remove it, as needed.
            string query = "Truncate table dbo.Estudiantes_busqueda";
            SqlCommand cmd = new SqlCommand(query, ConexionSQLServer.DevuelveCon());
            //cmd.CommandType = CommandType.Text;
            cmd.ExecuteNonQuery();
            this.estudiantes_busquedaTableAdapter.Fill(this.registroEstudiantesDataSet.Estudiantes_busqueda);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "Exec spBuscaEstudiante '" + tbNombreBusqueda.Text + "'";
            SqlCommand cmd = new SqlCommand(query, ConexionSQLServer.DevuelveCon());
            cmd.ExecuteNonQuery();
            this.estudiantes_busquedaTableAdapter.Fill(this.registroEstudiantesDataSet.Estudiantes_busqueda);
            //dataGridView1.Update();
            //dataGridView1.Refresh();
        }
    }
}
